﻿namespace DAIS.WikiSystem.Services.DTOs.Tag
{
    public class TagInfo
    {
        public int TagId { get; set; }
        public string Name { get; set; }
    }
}
