﻿using DAIS.WikiSystem.Models.Enums;

namespace DAIS.WikiSystem.Services.DTOs.Document
{
    public class GetDocumentResponse : DocumentInfo
    {
    }
}