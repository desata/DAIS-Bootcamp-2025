﻿namespace DAIS.WikiSystem.WebApp.Models.ViewModels
{
    public class TagViewModel
    {
        public int TagId { get; set; }
        public string Name { get; set; }
    }
}
