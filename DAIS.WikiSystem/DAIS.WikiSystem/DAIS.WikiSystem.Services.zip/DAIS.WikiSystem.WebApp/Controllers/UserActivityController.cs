﻿using Microsoft.AspNetCore.Mvc;

namespace DAIS.WikiSystem.WebApp.Controllers
{
    public class UserActivityController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
