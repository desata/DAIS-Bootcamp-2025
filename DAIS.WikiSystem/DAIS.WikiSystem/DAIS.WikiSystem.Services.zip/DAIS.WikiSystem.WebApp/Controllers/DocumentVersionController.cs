﻿using DAIS.WikiSystem.Services.Interfaces.Document;
using DAIS.WikiSystem.Services.Interfaces.DocumentVersion;
using DAIS.WikiSystem.WebApp.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DAIS.WikiSystem.WebApp.Controllers
{
    public class DocumentVersionController : Controller
    {
        private readonly IDocumentService _documentService;
        private readonly IDocumentVersionService _documentVersionService;

        public DocumentVersionController(
            IDocumentService documentService,
            IDocumentVersionService documentVersionService)
        {
            _documentService = documentService;
            _documentVersionService = documentVersionService;
        }

        public async Task<IActionResult> Index(int documentId)
        {
            var documentInfo = await _documentService.GetByIdAsync(documentId);
            var documentVersion = await _documentVersionService.GetActiveVersionByIdAsync(documentId);

            var viewModel = new DocumentPlusDocumentVersionViewModel
            {
                DocumentId = documentInfo.DocumentId,
                CategoryName = documentInfo.CategoryName,
                Title = documentInfo.Title,
                CreatorFirstName = documentInfo.CreatorFirstName,
                CreatorLastName = documentInfo.CreatorLastName,
                AccessLevel = documentInfo.AccessLevel,
                Tags = documentInfo.Tags,
                Version = documentVersion.Version,
                Content = documentVersion.Content,
                CreateDate = documentVersion.CreateDate

            };
            return View(viewModel);

        }
    }
}
