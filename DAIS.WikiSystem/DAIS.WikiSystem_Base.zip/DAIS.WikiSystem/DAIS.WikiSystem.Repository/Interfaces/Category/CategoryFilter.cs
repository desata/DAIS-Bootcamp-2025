﻿using System.Data.SqlTypes;

namespace DAIS.WikiSystem.Repository.Interfaces.Category
{
    public class CategoryFilter
    {
        public SqlString? Name { get; set; }
    }
}
