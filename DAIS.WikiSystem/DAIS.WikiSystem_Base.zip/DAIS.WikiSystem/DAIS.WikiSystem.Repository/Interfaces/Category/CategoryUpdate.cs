﻿namespace DAIS.WikiSystem.Repository.Interfaces.Category
{
    public class CategoryUpdate
    {
    }
}
