﻿using System.Data.SqlTypes;

namespace DAIS.WikiSystem.Repository.Interfaces.DocumentVersion
{
    public class DocumentVersionUpdate
    {
        public bool? IsArchived { get; set; }
    }
}