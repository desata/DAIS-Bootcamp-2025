﻿namespace DAIS.WikiSystem.Repository.Interfaces.Tag
{
    public class TagUpdate
    {
    }
}
