﻿using DAIS.WikiSystem.Models.Enums;
using DAIS.WikiSystem.Repository.Interfaces.Document;
using DAIS.WikiSystem.Repository.Interfaces.User;
using DAIS.WikiSystem.Services.DTOs.Document;
using DAIS.WikiSystem.Services.Interfaces.Document;
using DAIS.WikiSystem.Services.Interfaces.User;
using System.Data.SqlTypes;

namespace DAIS.WikiSystem.Services.Implementation.Document
{
    public class DocumentService : IDocumentService
    {
        private readonly IDocumentRepository _documentRepository;
        private readonly IUserService _userContext;

        public DocumentService(IDocumentRepository documentRepository, IUserService _userContext)
        {
            _documentRepository = documentRepository;
            this._userContext = _userContext;
        }

        public async Task<CreateDocumentResponse> CreateDocumentAsync(CreateDocumentRequest request)
        {

            var existingDocuments = await _documentRepository
                 .RetrieveCollectionAsync(new DocumentFilter
                 {
                     Title = new SqlString(request.Title),
                     CreatorId = request.CreatorId
                 })
                 .ToListAsync();

            if (existingDocuments.Any())
            {
                return new CreateDocumentResponse
                {
                    Success = false,
                    ErrorMessage = "You already have a document with this title."
                };
            }

            var document = new Models.Document
            {
                Title = request.Title,
                CreatorId = request.CreatorId,
                CategoryId = request.CategoryId,
                AccessLevel = request.AccessLevel,
                IsDeleted = request.IsDeleted
            };

            int newId = await _documentRepository.CreateAsync(document);

            return new CreateDocumentResponse
            {
                Success = true,
                DocumentId = newId
            };

        }

        public async Task<GetAllDocumentsResponse> GetByAccessLevelAsync(int accessLevelId)
        {
            var documents = await _documentRepository
               .RetrieveCollectionAsync(new DocumentFilter { AccessLevel = (AccessLevel)accessLevelId })
               .ToListAsync();

            var response = new GetAllDocumentsResponse
            {
                Documents = documents.Select(MapToDocumentInfo).ToList(),
                TotalCount = documents.Count
            };

            return response;
        }


        public async Task<GetAllDocumentsResponse> GetByCategoryIdAsync(int categoryId)
        {
            var documents = await _documentRepository
               .RetrieveCollectionAsync(new DocumentFilter { CategoryId = categoryId })
               .ToListAsync();

            var response = new GetAllDocumentsResponse
            {
                Documents = documents.Select(MapToDocumentInfo).ToList(),
                TotalCount = documents.Count
            };

            return response;
        }

        public async Task<GetAllDocumentsResponse> GetByCreatorIdAsync(int creatorId)
        {
            var documents = await _documentRepository
                .RetrieveCollectionAsync(new DocumentFilter { CreatorId = creatorId })
                .ToListAsync();

            var response = new GetAllDocumentsResponse
            {
                Documents = documents.Select(MapToDocumentInfo).ToList(),
                TotalCount = documents.Count
            };

            return response;

        }

        public async Task<GetDocumentResponse> GetByIdAsync(int documentId)
        {
            var document = await _documentRepository.RetrieveAsync(documentId);

            return (GetDocumentResponse)MapToDocumentInfo(document);

        }

        public async Task<GetAllDocumentsResponse> GetByTitleAsync(string title)
        {
            var documents = await _documentRepository
                .RetrieveCollectionAsync(new DocumentFilter { Title = title })
                .ToListAsync();

            var response = new GetAllDocumentsResponse
            {
                Documents = documents.Select(MapToDocumentInfo).ToList(),
                TotalCount = documents.Count
            };

            return response;
        }


        private DocumentInfo MapToDocumentInfo(Models.Document document)
        {
            return new DocumentInfo
            {
                DocumentId = document.DocumentId,
                Title = document.Title,
                AccessLevel = (AccessLevel)document.AccessLevel,
                IsDeleted = document.IsDeleted,
                CreatorId = document.CreatorId,
                CategoryId = document.CategoryId
            };

        }
    }
}
