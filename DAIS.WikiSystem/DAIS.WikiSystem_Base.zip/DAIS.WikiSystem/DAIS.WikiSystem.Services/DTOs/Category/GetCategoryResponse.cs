﻿namespace DAIS.WikiSystem.Services.DTOs.Category
{
    public class GetCategoryResponse : CategoryInfo
    {
    }
}
