﻿namespace DAIS.WikiSystem.Services.DTOs.Collection
{
    public class CollectionInfo
    {
        public int CollectionId { get; set; }
        public string Name { get; set; }
        public int CreatorId { get; set; }
    }
}
