﻿namespace DAIS.WikiSystem.Services.DTOs.Document
{
    public class GetDocumentResponse : DocumentInfo
    {
    }
}