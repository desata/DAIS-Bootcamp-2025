﻿namespace DAIS.WikiSystem.Services.DTOs.DocumentVersion
{
    public class GetActiveDocumentVersionByIdResponse : DocumentVersionInfo
    {

    }
}
