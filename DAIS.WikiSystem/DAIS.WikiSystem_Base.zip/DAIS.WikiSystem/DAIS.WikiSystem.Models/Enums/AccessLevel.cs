﻿namespace DAIS.WikiSystem.Models.Enums
{
    public enum AccessLevel
    {
        Public = 1,
        Internal = 2,
        Confidential = 3
    }
}
