﻿using DAIS.WikiSystem.Models.Enums;
using DAIS.WikiSystem.Repository;
using DAIS.WikiSystem.Repository.Implementation.Collection;
using DAIS.WikiSystem.Repository.Implementation.Document;
using DAIS.WikiSystem.Repository.Implementation.DocumentVersion;
using DAIS.WikiSystem.Repository.Implementation.Mappers;
using DAIS.WikiSystem.Repository.Implementation.User;
using DAIS.WikiSystem.Repository.Interfaces.User;
using DAIS.WikiSystem.Services.DTOs.Collection;
using DAIS.WikiSystem.Services.DTOs.Document;
using DAIS.WikiSystem.Services.DTOs.DocumentVersion;
using DAIS.WikiSystem.Services.DTOs.User;
using DAIS.WikiSystem.Services.Implementation.Authentication;
using DAIS.WikiSystem.Services.Implementation.Collection;
using DAIS.WikiSystem.Services.Implementation.Document;
using DAIS.WikiSystem.Services.Implementation.DocumentVersion;
using DAIS.WikiSystem.Services.Interfaces.Authentication;
using DAIS.WikiSystem.Services.Interfaces.Collection;
using DAIS.WikiSystem.Services.Interfaces.Document;
using DAIS.WikiSystem.Services.Interfaces.DocumentVersion;
using DAIS.WikiSystem.Services.Interfaces.User;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Text;


namespace DAIS.WikiSystem.ConsoleApplication
{
    class TestUserContextService : IUserService
    {
        public int UserId => 3;
        public Role Role => Role.Admin;
        public AccessLevel AccessLevel => AccessLevel.Internal;

        public Task<GetUserResponse> GetByIdAsync(int userId)
        {
            throw new NotImplementedException();
        }
    }
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;

            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            string connectionString = configuration.GetConnectionString("DefaultConnection");

            ConnectionFactory.Initialize(connectionString);


            var userContext = new TestUserContextService();

            // --- 2) Instantiate repositories (pass your real connection string) ---

            var docRepo = new DocumentRepository();
            var verRepo = new DocumentVersionRepository();
            var collRepo = new CollectionRepository();
            var mapRepo = new CollectionDocumentRepository();

            // --- 3) Instantiate services ---
            IDocumentService docService = new DocumentService(docRepo, userContext);
            IDocumentVersionService verService = new DocumentVersionService(verRepo);
            ICollectionService collService = new CollectionService(collRepo, mapRepo);
            //ICollectionDocumentService mapService = new CollectionDocumentService(mapRepo);

            // —————————————————————————————
            // 4) Create a new Document
            Console.WriteLine("► Creating Document…");
            var createDocReq = new CreateDocumentRequest
            {
                Title = "My neeext1 c Document Two",
                CategoryId = 2,
                AccessLevel = AccessLevel.Internal,
                IsDeleted = false,
                CreatorId = 3
                // CreatorId is ignored in service—pulled from IUserContextService
            };
            var createDocRes = await docService.CreateDocumentAsync(createDocReq);
            if (!createDocRes.Success)
            {
                Console.WriteLine($"✖ CreateDocument failed: {createDocRes.ErrorMessage}");
                return;
            }
            int docId = createDocRes.DocumentId;
            Console.WriteLine($"✔ Document created with ID = {docId}");

            // —————————————————————————————
            // 5) Create a new Document Version
            Console.WriteLine("► Creating Document Version…");
            var createVerReq = new CreateDocumentVersionRequest
            {
                DocumentId = docId,
                Content = "Initial draft content",
                Version = "v1.0",
                // CreateDate = DateTime.Now,

            };
            var createVerRes = await verService.CreateDocumentVersionAsync(createVerReq);
            if (!createVerRes.Success)
            {
                Console.WriteLine($"✖ CreateDocumentVersion failed: {createVerRes.ErrorMessage}");
                return;
            }
            Console.WriteLine($"✔ Version created with ID = {createVerRes.DocumentVersionId}");

            // —————————————————————————————
            // 6) Create a new Collection
            Console.WriteLine("► Creating Collection…");
            var createCollReq = new CreateCollectionRequest
            {
                Name = "My Test Collection",
                CreatorId = userContext.UserId
            };
            var collId = await collService.CreateCollectionAsync(createCollReq);
            Console.WriteLine($"✔ Collection created with ID = {collId.CollectionId}");

            // —————————————————————————————
            // 7) Add Document to the Collection
            Console.WriteLine("► Adding Document to Collection…");
            Console.WriteLine("► Adding Document to Collection…");
            var addDocsReq = new AddDocumentsToCollectionRequest
            {
                CollectionId = collId.CollectionId,
                DocumentIds = new List<int> { docId }
            };

            await collService.AddDocumentsToCollectionAsync(addDocsReq);
            Console.WriteLine($"✔ Added document {docId} to collection {collId.CollectionId}");

        }
    }
}