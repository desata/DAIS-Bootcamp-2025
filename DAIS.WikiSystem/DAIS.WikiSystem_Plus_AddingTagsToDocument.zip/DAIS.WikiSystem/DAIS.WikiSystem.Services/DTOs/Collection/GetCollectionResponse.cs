﻿namespace DAIS.WikiSystem.Services.DTOs.Collection
{
    public class GetCollectionResponse : CollectionInfo
    {
    }
}
