﻿namespace DAIS.WikiSystem.Services.DTOs.Category
{
    public class CategoryInfo
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
    }
}
