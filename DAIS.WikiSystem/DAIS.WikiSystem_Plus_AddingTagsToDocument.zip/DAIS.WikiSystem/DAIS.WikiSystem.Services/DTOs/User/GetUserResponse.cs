﻿namespace DAIS.WikiSystem.Services.DTOs.User
{
    public class GetUserResponse : UserInfo
    {
    }
}
