﻿namespace DAIS.WikiSystem.Services.DTOs.Tag
{
    public class GetTagResponse : TagInfo
    {
    }
}
