﻿using System.Data.SqlTypes;

namespace DAIS.WikiSystem.Repository.Interfaces.Tag
{
    public class TagFilter
    {
        public SqlString? Name { get; set; }
    }
}
