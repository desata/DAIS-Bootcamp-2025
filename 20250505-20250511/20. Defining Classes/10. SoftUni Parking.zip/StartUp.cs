﻿using System.Collections.Generic;
using System;
using System.Linq;

namespace SoftUniParking
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var car = new Car("Skoda", "Fabia", 65, "CC1856BG");
            var car2 = new Car("Audi", "A3", 110, "EB8787MN");

            Console.WriteLine(car);


            var parking = new Parking(5);
            Console.WriteLine(parking.AddCar(car));          
            Console.WriteLine(parking.AddCar(car));          
            Console.WriteLine(parking.AddCar(car2));         

            Console.WriteLine(parking.GetCar("EB8787MN"));   

            Console.WriteLine(parking.RemoveCar("EB8787MN"));
            Console.WriteLine(parking.Count);                

        }
    }

    public class Car
    {
        public Car(string make, string model, int horsePower, string registrationNumber)
        {
            Make = make;
            Model = model;
            HorsePower = horsePower;
            RegistrationNumber = registrationNumber;
        }

        public string Make { get; set; }
        public string Model { get; set; }
        public int HorsePower { get; set; }
        public string RegistrationNumber { get; set; }

        public override string ToString()
        {
            return $"Make: {Make}{Environment.NewLine}" +
                   $"Model: {Model}{Environment.NewLine}" +
                   $"HorsePower: {HorsePower}{Environment.NewLine}" +
                   $"RegistrationNumber: {RegistrationNumber}";
        }
    }

    public class Parking
    {
        private List<Car> cars;
        private int capacity;

        public Parking(int capacity)
        {
            this.capacity = capacity;
            cars = new List<Car>();
        }

        public int Count => cars.Count;

        public string AddCar(Car car)
        {
            if (cars.Any(c => c.RegistrationNumber == car.RegistrationNumber))
            {
                return "Car with that registration number, already exists!";
            }

            if (cars.Count >= capacity)
            {
                return "Parking is full!";
            }

            cars.Add(car);
            return $"Successfully added new car {car.Make} {car.RegistrationNumber}";
        }

        public string RemoveCar(string registrationNumber)
        {
            Car car = cars.FirstOrDefault(c => c.RegistrationNumber == registrationNumber);

            if (car == null)
            {
                return "Car with that registration number, doesn't exist!";
            }

            cars.Remove(car);
            return $"Successfully removed {registrationNumber}";
        }

        public Car GetCar(string registrationNumber)
        {
            return cars.FirstOrDefault(c => c.RegistrationNumber == registrationNumber);
        }

        public void RemoveSetOfRegistrationNumber(List<string> registrationNumbers)
        {
            cars.RemoveAll(c => registrationNumbers.Contains(c.RegistrationNumber));
        }
    }
}
