﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wiki.Models
{
    public class Collection
    {
        public string Name { get; set; }
        public User CreatedBy { get; set; }
        public List<Document> Documents { get; private set; } = new();

        

        public Collection(string name, User createdBy)
        {
            Name = name;
            CreatedBy = createdBy;
        }

        public void AddToCollection(Document document)
        {
            if (!Documents.Contains(document))
            {
                Documents.Add(document);
                Console.WriteLine($"Document '{document.Title}' added to collection '{Name}'.");
            }
            else
            {
                Console.WriteLine($"Document '{document.Title}' is already in the collection.");
            }
        }

        List<Collection> allCollections = new();

        public List<Document> GetDocuments()
        {
            return Documents;
        }
    }
}