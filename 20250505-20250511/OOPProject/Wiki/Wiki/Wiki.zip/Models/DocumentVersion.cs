﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wiki.Models
{
    public class DocumentVersion
    {
        public int VersionNumber { get; set; }
        public DateTime UploadedAt { get; set; }


    }
}
