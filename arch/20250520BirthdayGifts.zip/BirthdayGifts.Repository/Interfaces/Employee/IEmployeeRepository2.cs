﻿using BirthdayGifts.Repository.Base2;

namespace BirthdayGifts.Repository.Interfaces.Employee
{
    public interface IEmployeeRepository2 : IBaseRepository2<Models.Employee, EmployeeFilter, EmployeeUpdate>
    {
    }
}