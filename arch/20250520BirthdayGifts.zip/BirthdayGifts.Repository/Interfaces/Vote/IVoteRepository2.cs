﻿using BirthdayGifts.Repository.Base2;

namespace BirthdayGifts.Repository.Interfaces.Vote
{
    public interface IVoteRepository2 : IBaseRepository2<Models.Vote, VoteFilter, VoteUpdate> 
    {
    }
}
