﻿using BirthdayGifts.Repository.Base2;

namespace BirthdayGifts.Repository.Interfaces.VotingSession
{
    public interface IVotingSessionRepository2 : IBaseRepository2<Models.VotingSession, VotingSessionFilter, VotingSessionUpdate>
    {
    }
}
