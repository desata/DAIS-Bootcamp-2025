﻿using BirthdayGifts.Repository.Base2;

namespace BirthdayGifts.Repository.Interfaces.Gift
{
    public interface IGiftRepository2 : IBaseRepository2<Models.Gift, GiftFilter, GiftUpdate> 
    {
    }
}
