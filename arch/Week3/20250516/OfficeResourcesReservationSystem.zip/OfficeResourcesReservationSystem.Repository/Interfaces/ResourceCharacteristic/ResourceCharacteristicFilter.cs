﻿using System.Data.SqlTypes;

namespace OfficeResourcesReservationSystem.Repository.Interfaces.ResourceCharacteristic
{
    public class ResourceCharacteristicFilter
    {
        public SqlString? Name { get; set; }
    }
}
