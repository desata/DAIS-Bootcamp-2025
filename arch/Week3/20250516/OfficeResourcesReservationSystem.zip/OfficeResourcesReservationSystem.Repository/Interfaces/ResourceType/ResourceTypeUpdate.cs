﻿using System.Data.SqlTypes;

namespace OfficeResourcesReservationSystem.Repository.Interfaces.ResourceType
{
    public class ResourceTypeUpdate
    {
        public SqlString? Name { get; set; }
    }
}