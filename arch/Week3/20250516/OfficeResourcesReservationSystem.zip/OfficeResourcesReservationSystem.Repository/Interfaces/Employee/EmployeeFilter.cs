﻿using System.Data.SqlTypes;

namespace OfficeResourcesReservationSystem.Repository.Interfaces.Employee
{
    public class EmployeeFilter
    {
        
        public SqlString? Username { get; set; }
    }
}
