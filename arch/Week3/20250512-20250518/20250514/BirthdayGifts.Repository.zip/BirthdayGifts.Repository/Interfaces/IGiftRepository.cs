﻿using BirthdayGifts.Models;
using BirthdayGifts.Repository.Base;

namespace BirthdayGifts.Repository.Interfaces
{
    public interface IGiftRepository : IBaseRepository<Gift>
    {
    }
}
