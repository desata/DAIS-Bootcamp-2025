﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wiki.Models
{
    public class Collection
    {
        public int CollectionId { get; set; }

        [Required]
        [StringLength(500, MinimumLength = 2 , ErrorMessage = "Collection name must be between 2 and 500 characters")]
        public required string Name { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string? Description { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreatedAt { get; set; }


        [DataType(DataType.DateTime)]
        public DateTime? UpdatedAt { get; set; }

        [Required(ErrorMessage = "Creator of collection is required")]
        public int CreatorId { get; set; }

        [Required]
        public bool IsDeleted { get; set; }
    }
}
