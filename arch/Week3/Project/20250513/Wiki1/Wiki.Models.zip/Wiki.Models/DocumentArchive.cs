﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wiki.Models.Enums;

namespace Wiki.Models
{
    public class DocumentArchive
    {
        public int ArchiveId { get; set; }
        [Required]
        public required string Title { get; set; }
        [Required]
        public int AuthorId { get; set; }
        [Required]
        public int CategoryId { get; set; }
        [Required]
        public required string Tags { get; set; }
        [Required]
        public int AccessLevel { get; set; }
        [Required]
        public required string Version { get; set; }
        [Required]
        public required string Content { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime ArchivedAt { get; set; }

        [Required]
        public int OriginalDocumentId { get; set; }
    }
}
