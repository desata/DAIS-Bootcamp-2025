﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wiki.Models.Enums;

namespace Wiki.Models
{
    public class DocumentInformation
    {
        public int DocumentInformationId { get; set; }

        [Required(ErrorMessage = "Content is required")]
        public required string Content { get; set; }

        [Required(ErrorMessage = "Version is required")]
        [StringLength(12, MinimumLength = 1, ErrorMessage = "Version must be up to 12 characters")]
        public required string Version { get; set; }

        [Required(ErrorMessage = "Access level is required")]
        public AccessLevel AccessLevel { get; set; }

        [Required(ErrorMessage = "Create date is required")]
        [DataType(DataType.DateTime)]
        public DateTime CreatedAt { get; set; }

        [Required(ErrorMessage = "Upload date is required")]
        [DataType(DataType.DateTime)]
        public DateTime UploadedAt { get; set; }

        [Required(ErrorMessage = "Document is required")]
        public int DocumentId { get; set; }
    }
}
