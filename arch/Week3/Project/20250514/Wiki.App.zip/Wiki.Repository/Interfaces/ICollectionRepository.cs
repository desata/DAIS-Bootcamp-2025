﻿using Wiki.Repository.Base;
using Wiki.Models;

namespace Wiki.Repository.Interfaces
{
    public interface ICollectionRepository : IBaseRepository<Collection>
    {
    }
}
