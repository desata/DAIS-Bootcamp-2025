﻿using Wiki.Models;
using Wiki.Repository.Base;

namespace Wiki.Repository.Interfaces
{
    public interface IEmployeeRepository : IBaseRepository<Employee>
    {    
    }
}
