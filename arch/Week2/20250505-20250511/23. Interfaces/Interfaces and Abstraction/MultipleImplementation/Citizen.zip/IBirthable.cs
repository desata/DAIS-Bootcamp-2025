﻿namespace PersonInfo
{
    internal interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}