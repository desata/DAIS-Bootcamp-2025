﻿
namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>();
            
            for (int i = 0; i < n; i++)
            {
                string[] vehicle = Console.ReadLine().Split();
                string model = vehicle[0];
                double fuelAmount = double.Parse(vehicle[1]);
                double fuelConsumptionPerKilometer = double.Parse(vehicle[2]);
                Car car = new Car(model, fuelAmount, fuelConsumptionPerKilometer);
                cars.Add(car);
            }

            string command = Console.ReadLine();

            while (command != "End")
            {
                string[] commandArgs = command.Split();
                string carModel = commandArgs[1];
                double distance = double.Parse(commandArgs[2]);
                Car carToDrive = cars.FirstOrDefault(c => c.Model == carModel);
                if (carToDrive != null)
                {
                    carToDrive.Drive(distance);
                }
                command = Console.ReadLine();
            }

            foreach (var car in cars)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:F2} {car.TravelledDistance}");
            }
        }
    }

    public class Car
    {


        public string Model { get; set; }
        public double FuelAmount { get; set; }
        double FuelConsumptionPerKilometer { get; set; }
        public double TravelledDistance { get; set; }

        public Car(string model, double fuelAmount, double fuelConsumptionPerKilometer)
        {
            Model = model;
            FuelAmount = fuelAmount;
            FuelConsumptionPerKilometer = fuelConsumptionPerKilometer;
            TravelledDistance = 0;
        }

        public void Drive(double amountOfKm)
        {
            if (FuelAmount >= FuelConsumptionPerKilometer * amountOfKm)
            {
                FuelAmount -= FuelConsumptionPerKilometer * amountOfKm;
                TravelledDistance += amountOfKm;
            }
            else
            {
                Console.WriteLine("Insufficient fuel for the drive");
            }
        }
    }
}