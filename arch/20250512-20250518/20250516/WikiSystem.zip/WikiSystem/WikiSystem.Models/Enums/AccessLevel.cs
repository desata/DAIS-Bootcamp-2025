﻿namespace WikiSystem.Models.Enums
{
    public enum AccessLevel
    {
        Confidential = 1,
        Private = 2,
        Public = 3
    }
}
