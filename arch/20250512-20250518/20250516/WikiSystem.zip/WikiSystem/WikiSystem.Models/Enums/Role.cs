﻿namespace WikiSystem.Models.Enums
{
    public enum Role
    {
        Admin = 1,
        Editor = 2,
        Viewer = 3
    }
}
