﻿using System.Data.SqlTypes;

namespace WikiSystem.Repository.Interfaces.Collection
{
    public class CollectionUpdate
    {
        public SqlString? Name { get; set; }
    }
}
