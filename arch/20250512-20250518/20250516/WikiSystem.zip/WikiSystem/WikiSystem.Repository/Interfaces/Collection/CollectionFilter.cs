﻿using System.Data.SqlTypes;

namespace WikiSystem.Repository.Interfaces.Collection
{
    public class CollectionFilter
    {
        public SqlString? Name { get; set; }
    }
}
