﻿namespace WikiSystem.Repository.Interfaces.Document
{
    public class DocumentUpdate
    {
    }
}
