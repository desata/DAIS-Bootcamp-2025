﻿namespace WikiSystem.Repository.Interfaces.DocumentVersion
{
    public class DocumentVersionUpdate
    {
    }
}
