﻿using System.Data.SqlTypes;

namespace WikiSystem.Repository.Interfaces.Category
{
    public class CategoryUpdate
    {
        public SqlString? Name { get; set; }

    }
}