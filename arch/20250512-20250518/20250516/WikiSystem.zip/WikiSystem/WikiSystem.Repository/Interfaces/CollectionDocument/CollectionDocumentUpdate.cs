﻿namespace WikiSystem.Repository.Interfaces.CollectionDocument
{
    public class CollectionDocumentUpdate
    {
    }
}
